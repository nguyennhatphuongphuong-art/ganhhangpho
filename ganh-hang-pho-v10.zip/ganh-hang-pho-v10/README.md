# Gánh Hàng Phố V10 — 2D Art Pack

Bộ asset 2D mới từ concept sheet: nhân vật tĩnh, nguyên liệu minh họa và 6 phong cảnh riêng. Nhân vật xuất hiện/mất theo gameplay, không cần animation phức tạp.
